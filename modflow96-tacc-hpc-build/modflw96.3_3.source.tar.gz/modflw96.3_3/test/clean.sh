rm -f bcf2ss.lst check.out ibs.lst str.lst fhb.lst
rm -f tlkp1.lst tlkp1.drw tlkp1.flw twri.lst fhb.hd fhb.cbc
rm -f restest.lst go tlkp1.bud tlkp1.ddn
rm -f bcf2ss.log ibs.log str.log twri.log tlkp1.log restest.log fhb.log
